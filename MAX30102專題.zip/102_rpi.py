import max30102
import numpy as np
import random as rm
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import threading
import socket
import json
m = max30102.MAX30102()
def data(): 
    global BigListA
    BigListA=[]
    while True:
        BigListA = m.read_sequential()
       
        
# 1 sample is read and used for HR/SpO2 calculation in a single loop
#///////////////////////////////////////////////

def socket_sever():
    global BigListA
    ip= '192.168.10.121'
    port=2050
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    print(' ------  connect reset ----')
    sock.bind((ip,port))

    sock.listen(2)
    print(' ------  wait for connect with ----')
    c, addr = sock.accept()
    print ("Socket Up and running with a connection from",addr)
    A=100 
    while True:
            A=A+1
            js = json.dumps(BigListA)
            rcvdData = c.recv(1024).decode()
            print ("S:",rcvdData)
            c.send(bytes(js.encode('utf-8')))

        
    c.close()

if __name__=='__main__':

    threading.Thread(target =socket_sever, args = ()).start()
    data()
